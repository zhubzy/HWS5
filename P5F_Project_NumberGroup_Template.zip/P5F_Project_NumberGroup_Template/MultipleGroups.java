import java.util.List;
import java.util.ArrayList;

public class MultipleGroups implements NumberGroup
   {
   private List<NumberGroup> groupList;
   
       
   } // end class MulitpleGroups

