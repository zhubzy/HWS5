public abstract interface NumberGroup
   {

    
   } // end interface NumberGroup
    