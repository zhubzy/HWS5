public class MultipleGroupsDriver
   {
   public static void main( String[] args )
      {
      MultipleGroups group = new MultipleGroups();
      
      System.out.println( group.contains( 2 ) );
      System.out.println( group.contains( 9 ) );           
      System.out.println( group.contains( 6 ) );
      
      } // end method main
       
   } // end class RangeDriver