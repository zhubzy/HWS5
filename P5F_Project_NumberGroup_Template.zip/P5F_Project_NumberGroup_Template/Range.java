public class Range 
   {
   
   } // end class Range